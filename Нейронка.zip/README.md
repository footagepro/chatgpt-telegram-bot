# ChatGPT Telegram Бот

## 📦 Установка

1. Установи зависимости:

```bash
pip install -r requirements.txt
```

2. Создай `.env` файл и вставь свои ключи:

```
TELEGRAM_BOT_TOKEN=your-telegram-bot-token
OPENAI_API_KEY=your-openai-api-key
```

3. Запусти бота:

```bash
python main.py
```

## ⚙️ Требования
- Python 3.9+
- Ключ OpenAI (https://platform.openai.com/)
- Токен Telegram бота (через @BotFather)
